package chess;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ChessBoardImTest {

    @Test
    void addPiece() {
    }

    @Test
    void firstadds() {
    }

    @Test
    void getPiece() {
    }

    @Test
    void removePiece() {
    }

    @Test
    void resetBoard() {
    }
}