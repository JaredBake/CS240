package webSocketMessages.userCommands;

public class JoinPlayer {
}
