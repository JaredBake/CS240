package webSocketMessages.userCommands;

import chess.ChessMove;
import chess.ChessMoveIm;

public class MakeMove {

    private ChessMoveIm move;

    public MakeMove(){

    }
}
