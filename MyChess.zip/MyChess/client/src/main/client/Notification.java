package client;

public class Notification {
}
