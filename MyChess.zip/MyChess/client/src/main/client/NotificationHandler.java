package client;

public interface NotificationHandler {
    void notify(Notification notification);
}