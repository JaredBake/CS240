package Commands;

public class Leave {
}
